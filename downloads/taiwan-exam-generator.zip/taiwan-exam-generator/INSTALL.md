# 給 AI 的一次安裝指引

使用者只需要說「安裝這個技能」，後續說「依照 Taiwan Exam 出題」。
請你完成環境支援的操作，不要求使用者操作終端機、搬資料夾或理解套件名稱。
目標是原生技能安裝與後續重用，不是每個對話重新抓取 GitHub。

## 先找已安裝版本

查目前平台的技能清單／原生安裝器，確認 `taiwan-exam-generator` 是否已啟用。
若存在且完整，直接沿用；不要為了「確保最新」重新下載、覆寫或重裝。
缺少某科資料、暫時不能連網或非必要依賴缺少，不是重裝技能的理由。
若未出現在本次清單，先檢查啟用狀態、安裝範圍與是否需要新對話／重新載入。
更新只有在使用者要求，或已確認損壞並取得修復授權後才處理；保留個人修改及私人考試資料。

## 尚未安裝時

- **Codex 本機環境**：優先用內建 Skill Installer 從本 GitHub 儲存庫根目錄安裝完整技能，名稱為 `taiwan-exam-generator`。以實際安裝器的使用者級位置為準，不放入會被清除的對話暫存；不能把 clone 到普通工作目錄當成已註冊技能。
- **Claude Code 本機環境**：透過可用的檔案／安裝工具將完整技能放入個人技能目錄 `~/.claude/skills/taiwan-exam-generator/`，確認 `SKILL.md` 可被原生技能清單找到。不要覆寫已存在內容。此範圍不自動涵蓋 Claude 網頁或雲端。
- **Claude 網頁版**：使用帳號的 Skills 安裝入口。若你沒有上傳或確認權限，只請使用者完成首次所需的介面動作（Customize → Skills，上傳並啟用），不要說每個新對話都要上傳。
- **ChatGPT 網頁版**：檢查當前帳號是否提供可用的原生技能／外掛安裝入口或工具。使用其實際支援的流程；此儲存庫不是已上架外掛，不能憑空給出安裝按鈕或編造工具。沒有入口時，明確說明該環境不能完成使用者要求的持久安裝，不能自動改成單次附件方案。

技能包：https://github.com/niansia/taiwan-exam/raw/refs/heads/main/downloads/taiwan-exam-generator.zip

取得檔案不等於安裝。保留整個技能目錄的參考文件、腳本、結構規格與 exam_packs；核對 PACKAGE_MANIFEST.json 的檔案清單及雜湊。不要每次出題下載此包。平台自行載入已安裝資源不屬於要求使用者重新安裝。

## 驗證及簡短回報

確認原生技能已註冊／啟用，說明它適用於哪個帳號、工作區或本機範圍。
只需告訴使用者下一句：「請依照 Taiwan Exam 這個 Skill，幫我出學測數 A 考卷一份。」
如平台需要，請使用者開新對話測一次，不要求重新附檔；沒有實際測過新對話，應標示「跨對話呼叫待確認」。
不要聲稱在本機安裝一次就自動同步所有平台／裝置。

**安裝成功不是完整考卷已校準。** 後續出題依 SKILL.md 與 references/first-use.md，優先沿用可取得且雜湊未變的有效參考資料。臨時執行容器、帳號技能儲存與私人試卷工作目錄的保存範圍不同，不可混為一談。

官方依據（2026-09-09 核對）：[Codex 技能](https://learn.chatgpt.com/docs/build-skills)、[Claude 技能](https://support.claude.com/en/articles/12512180-use-skills-in-claude)、[Claude Code 技能範圍](https://code.claude.com/docs/en/skills)。
